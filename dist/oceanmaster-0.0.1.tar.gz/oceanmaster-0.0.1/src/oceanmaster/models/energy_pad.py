from oceanmaster.models.point import Point


class EnergyPad:
    id: int
    location: Point
    available: int
    ticksleft: int
