from .Point import Point
from oceanmaster.Constants import AlgaeType

class Algae:
    location: Point
    is_poison: AlgaeType
