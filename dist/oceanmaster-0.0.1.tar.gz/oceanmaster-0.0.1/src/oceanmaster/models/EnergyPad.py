from oceanmaster.models.Point import Point

class EnergyPad:
    id: int
    location: Point
    available: int
    ticksleft: int