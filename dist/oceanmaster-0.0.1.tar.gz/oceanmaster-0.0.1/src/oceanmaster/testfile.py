def giveNumber():
    return 1
