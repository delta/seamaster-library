from oceanmaster.models.Point import Point

class Bank:
    id: int
    location: Point
    deposit_occuring: int
    deposit_amount: int
    deposit_owner: int
    depositticksleft: int
