from oceanmaster.models.Point import Point

class VisibleScrap:
    location : Point
    amount: int