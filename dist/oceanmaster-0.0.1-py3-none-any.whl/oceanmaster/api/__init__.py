"""
Docstring for oceanmaster.api
"""

from .game_api import GameAPI

__all__ = [
    "GameAPI",
]
